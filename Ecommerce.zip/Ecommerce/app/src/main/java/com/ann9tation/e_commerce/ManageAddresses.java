package com.ann9tation.e_commerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.ann9tation.adapter.AddressAdapter;
import com.ann9tation.model.Address;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ManageAddresses extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView addressRecycler;
    private FloatingActionButton btn_add_address;
    private ImageView ic_back,ic_notification;
    AddressAdapter addressAdapter;
    List<Address> addressList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_addresses);

        initViews();
        initListners();

        populateAddressList();

        setAddressRecycler(addressList);


    }

    private void initListners() {
        ic_back.setOnClickListener(this);
        ic_notification.setOnClickListener(this);
        btn_add_address.setOnClickListener(this);
    }

    private void populateAddressList() {
        addressList=new ArrayList<>();
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","HOME"));
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","WORK"));
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","WORK"));
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","HOME"));
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","HOME"));
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","WORK"));
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","HOME"));
        addressList.add(new Address("Mr. Dummy Name","b-007,Mumbai (west),near bank,416 602","+915963214785","WORK"));
    }

    private void setAddressRecycler(List<Address> dataList) {
        addressRecycler.setLayoutManager(new LinearLayoutManager(this));
        addressAdapter=new AddressAdapter(this,dataList);
        addressRecycler.setAdapter(addressAdapter);
    }

    private void initViews() {
        addressRecycler=findViewById(R.id.activity_manage_addresses_address_recycler);
        btn_add_address=findViewById(R.id.activity_manage_addresses_fab_add_address);
        ic_back=findViewById(R.id.activity_manage_addresses_iv_back);
        ic_notification=findViewById(R.id.activity_manage_addresses_iv_notification);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.activity_manage_addresses_iv_back:
                onBackPressed();
                break;
            case R.id.activity_manage_addresses_iv_notification:
                Toast.makeText(this, "Notification.", Toast.LENGTH_SHORT).show();;
                break;
            case R.id.activity_manage_addresses_fab_add_address:
//                TODO add address activity
                Toast.makeText(this, "Add Address.", Toast.LENGTH_SHORT).show();;

                break;
        }
    }
}