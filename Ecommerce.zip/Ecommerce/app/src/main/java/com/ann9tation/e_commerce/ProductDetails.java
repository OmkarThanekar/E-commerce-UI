package com.ann9tation.e_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ann9tation.model.YourCart;

public class ProductDetails extends AppCompatActivity implements View.OnClickListener {
    String pName,pDesc,pPrice,pWt_or_piece;
    int pImage;
    private ImageView productImage,ic_back,ic_cart,ic_plus,ic_minus;
    private TextView tv_pName,tv_pDesc,tv_pPrice,tv_pQty,tv_Wt_or_piece;
    private Button btn_addtocart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        getIntentData();
        initViews();
        initListners();
        setValues();

    }

    private void setValues() {
        tv_pName.setText(pName);
        tv_pDesc.setText(pDesc);
        tv_pPrice.setText(pPrice);
        productImage.setImageResource(pImage);
        tv_Wt_or_piece.setText(pWt_or_piece);
    }

    private void initListners() {
        ic_back.setOnClickListener(this);
        ic_cart.setOnClickListener(this);
        ic_plus.setOnClickListener(this);
        ic_minus.setOnClickListener(this);
        btn_addtocart.setOnClickListener(this);
    }

    private void initViews() {
        productImage=findViewById(R.id.product_details_iv_product);
        ic_back=findViewById(R.id.product_detail_iv_back);
        ic_cart=findViewById(R.id.product_details_iv_cart);
        ic_minus=findViewById(R.id.product_details_iv_minus);
        ic_plus=findViewById(R.id.product_details_iv_plus);
        tv_pName=findViewById(R.id.product_details_tv_product_name);
        tv_pDesc=findViewById(R.id.product_details_tv_product_description);
        tv_pPrice=findViewById(R.id.product_details_tv_price);
        tv_pQty=findViewById(R.id.product_details_tv_qty);
        tv_Wt_or_piece=findViewById(R.id.product_details_tv_weight_or_piece);

        btn_addtocart=findViewById(R.id.product_details_btn_add_cart);
    }

    private void getIntentData() {
        Intent i=getIntent();
        pName=i.getStringExtra("name");
        pDesc=i.getStringExtra("desc");
        pPrice=i.getStringExtra("price");
        pImage=i.getIntExtra("image",R.drawable.b1);
        pWt_or_piece=i.getStringExtra("weight/piece");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.product_detail_iv_back:
                onBackPressed();
                break;
            case R.id.product_details_iv_cart:
                Intent cartIntent = new Intent(this, CartActivity.class);
                startActivity(cartIntent);
                break;
            case  R.id.product_details_iv_plus:
                tv_pQty.setText(Integer.toString(Integer.parseInt(tv_pQty.getText().toString())+1));
                break;
            case R.id.product_details_iv_minus:
                if (Integer.parseInt(tv_pQty.getText().toString())>1)
                    tv_pQty.setText(Integer.toString(Integer.parseInt(tv_pQty.getText().toString())-1));
                else
                    Toast.makeText(this, "Minimum Quantity should be 1.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.product_details_btn_add_cart:
                Toast.makeText(this, "Added to cart.", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}