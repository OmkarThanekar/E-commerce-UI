package com.ann9tation.e_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText et_email,et_password,et_confirm_password;
    private Button btn_signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        initViews();
        intListeners();
    }

    private void initViews() {
        et_email=findViewById(R.id.signup_et_email);
        et_password=findViewById(R.id.signup_et_password);
        et_confirm_password=findViewById(R.id.signup_et_confirmpassword);
        btn_signup=findViewById(R.id.signup_btn_signup);
    }

    private void intListeners() {
        btn_signup.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.signup_btn_signup:
                if (et_password.getText().toString().equals(et_confirm_password.getText().toString()) && !et_password.getText().toString().isEmpty() && !et_confirm_password.getText().toString().isEmpty())
                Toast.makeText(this, "Email:"+et_email.getText().toString()+".\n"+"Password:"+et_password.getText().toString()
                        +".\n"+"Confirm Password:"+et_confirm_password.getText().toString()+".", Toast.LENGTH_SHORT).show();
                else if(!et_password.getText().toString().equals(et_confirm_password.getText().toString()))
                    Toast.makeText(this, "Passwords don't match.", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(this, "Please fill all the fields.", Toast.LENGTH_SHORT).show();

        }
    }
}