package com.ann9tation.e_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView ic_back,ic_notification,ic_cart,ic_edit,ic_change_password,ic_manage_addresses,
            ic_help_and_support,ic_payment_and_transaction,ic_recent_orders,ic_logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        initViews();
        initListners();


    }

    private void initListners() {
        ic_back.setOnClickListener(this);
        ic_notification.setOnClickListener(this);
        ic_cart.setOnClickListener(this);
        ic_edit.setOnClickListener(this);
        ic_change_password.setOnClickListener(this);
        ic_manage_addresses.setOnClickListener(this);
        ic_help_and_support.setOnClickListener(this);
        ic_payment_and_transaction.setOnClickListener(this);
        ic_recent_orders.setOnClickListener(this);
        ic_logout.setOnClickListener(this);
    }

    private void initViews() {
        ic_back=findViewById(R.id.activity_profile_iv_back);
        ic_notification=findViewById(R.id.activity_profile_iv_notification);
        ic_cart=findViewById(R.id.activity_profile_iv_cart);
        ic_edit=findViewById(R.id.activity_profile_iv_edit_info);
        ic_change_password=findViewById(R.id.activity_profile_iv_change_password);
        ic_manage_addresses=findViewById(R.id.activity_profile_iv_manage_addresses);
        ic_help_and_support=findViewById(R.id.activity_profile_iv_help_and_support);
        ic_payment_and_transaction=findViewById(R.id.activity_profile_iv_payment_and_transaction);
        ic_recent_orders=findViewById(R.id.activity_profile_iv_recent_orders);
        ic_logout=findViewById(R.id.activity_profile_iv_logout);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.activity_profile_iv_back:
                onBackPressed();
                break;
            case R.id.activity_profile_iv_notification:
                Toast.makeText(this, "Notification.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.activity_profile_iv_cart:
                Intent cartIntent=new Intent(this,CartActivity.class);
                startActivity(cartIntent);
                break;
            case R.id.activity_profile_iv_edit_info:
//                TODO Edit Info activity
                Toast.makeText(this, "Edit Info Activity.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.activity_profile_iv_change_password:
//                TODO Change Password Activity
                Toast.makeText(this, "Change Password Activity.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.activity_profile_iv_manage_addresses:
                Intent manageAddressIntent=new Intent(this,ManageAddresses.class);
                startActivity(manageAddressIntent);
                break;
            case R.id.activity_profile_iv_help_and_support:
//                TODO HELP & SUPPORT ACTIVITY
                Toast.makeText(this, "Help & Support.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.activity_profile_iv_payment_and_transaction:
//                TODO Payment Activity
                Toast.makeText(this, "Payment.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.activity_profile_iv_recent_orders:
                Toast.makeText(this, "Recent Orders.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.activity_profile_iv_logout:
                Intent logoutIntent =new Intent(this,LoginActivity.class);
                startActivity(logoutIntent);
                finish();
                break;
        }


    }
}