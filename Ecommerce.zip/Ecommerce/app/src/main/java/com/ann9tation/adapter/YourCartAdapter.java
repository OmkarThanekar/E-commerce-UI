package com.ann9tation.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.ann9tation.e_commerce.R;
import com.ann9tation.model.YourCart;

import java.util.List;

public class YourCartAdapter extends RecyclerView.Adapter<YourCartAdapter.YourCartViewHolder> {



    Context context;
    List<YourCart> yourcartlist;
    private OnItemClickListener myListner;

    public void setOnClickListener(OnItemClickListener listener) {
        myListner = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onPlusClick(int position, TextView tv_Quantity, TextView tv_Subtotal, String price);

        void onMinusClick(int position, TextView tv_Quantity,TextView tv_Subtotal, String price);

        void onDeleteClick(int position);
    }

    public YourCartAdapter(Context context, List<YourCart> yourcartlist) {
        this.context = context;
        this.yourcartlist = yourcartlist;
    }

    @NonNull
    @Override
    public YourCartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.your_cart_row_item, parent, false);

        return new YourCartViewHolder(view,myListner);
    }

    @Override
    public void onBindViewHolder(@NonNull YourCartViewHolder holder, int position) {

        holder.pImage.setImageResource(yourcartlist.get(position).getImageUrl());
        holder.tv_Productname.setText(yourcartlist.get(position).getName());
        holder.tv_Price.setText(yourcartlist.get(position).getPrice() + " per " + yourcartlist.get(position).getUnit());
        holder.tv_Quantity.setText(yourcartlist.get(position).getQuantity());
        holder.tv_Subtotal.setText(Integer.toString(Integer.parseInt(holder.tv_Quantity.getText().toString())*Integer.parseInt((yourcartlist.get(position).getPrice().substring(2)))));

//        totalprice=totalprice+Integer.parseInt(holder.tv_Subtotal.getText().toString());
//        Log.d("total", "onBindViewHolder: "+totalprice);
    }

    @Override
    public int getItemCount() {
        return yourcartlist.size();
    }


    public class YourCartViewHolder extends RecyclerView.ViewHolder {

        ImageView pImage, ic_plus, ic_minus, ic_delete;
        TextView tv_Productname, tv_Price, tv_Subtotal, tv_Quantity;
        ConstraintLayout parentLayout;

        public YourCartViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            pImage = itemView.findViewById(R.id.cart_item_iv_product_image);
            ic_plus = itemView.findViewById(R.id.cart_item_iv_plus);
            ic_minus = itemView.findViewById(R.id.cart_item_iv_minus);
            ic_delete = itemView.findViewById(R.id.cart_item_iv_delete);

            tv_Productname = itemView.findViewById(R.id.cart_item_tv_product_name);
            tv_Price = itemView.findViewById(R.id.cart_item_tv_product_price);
            tv_Subtotal = itemView.findViewById(R.id.cart_item_tv_product_subtotal);
            tv_Quantity = itemView.findViewById(R.id.cart_item_tv_product_quantity);
            parentLayout=itemView.findViewById(R.id.cart_item_parent);

            parentLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null){
                        int position=getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION)
                        {
                            listener.onItemClick(position);
                        }
                    }
                }
            });

            ic_plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onPlusClick(position,tv_Quantity,tv_Subtotal,yourcartlist.get(position).getPrice());
                        }
                    }
                }
            });

            ic_minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener!=null)
                    {
                        int position=getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            listener.onMinusClick(position,tv_Quantity,tv_Subtotal,yourcartlist.get(position).getPrice());
                        }
                    }
                }
            });

            ic_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener!=null)
                    {
                        int position=getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            listener.onDeleteClick(position);
                        }
                    }
                }
            });
        }
    }
}
