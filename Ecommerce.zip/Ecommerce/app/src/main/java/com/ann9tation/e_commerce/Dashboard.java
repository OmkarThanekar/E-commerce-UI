package com.ann9tation.e_commerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.ann9tation.adapter.LatestProductAdapter;
import com.ann9tation.adapter.OurProductAdapter;
import com.ann9tation.model.LatestProducts;
import com.ann9tation.model.OurProducts;

import java.util.ArrayList;
import java.util.List;

public class Dashboard extends AppCompatActivity implements View.OnClickListener {

    private ImageView ic_cart,ic_profile,ic_filter;
    private EditText et_search;
    private TextView tv_vegetables,tv_fruits;
    private RecyclerView latestProductRecycler,ourProductRecycler;
    LatestProductAdapter latestProductAdapter;
    List<LatestProducts> latestProductsList;

    OurProductAdapter ourProductAdapter;
    List<OurProducts> ourProductsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        initViews();
        initListner();

        populateLatestProductList();
        setLatestProductAdapter(latestProductsList);

        populateOurProductList();
        setOurProductRecycler(ourProductsList);


    }

    private void initListner() {
        ic_profile.setOnClickListener(this);
        ic_cart.setOnClickListener(this);
        ic_filter.setOnClickListener(this);
        tv_vegetables.setOnClickListener(this);
        tv_fruits.setOnClickListener(this);
    }


    private void populateLatestProductList() {
        latestProductsList= new ArrayList<>();
        latestProductsList.add(new LatestProducts(1,R.drawable.discountberry));
        latestProductsList.add(new LatestProducts(2,R.drawable.discountbrocoli));
        latestProductsList.add(new LatestProducts(3,R.drawable.discountberry));
        latestProductsList.add(new LatestProducts(4,R.drawable.discountbrocoli));
        latestProductsList.add(new LatestProducts(5,R.drawable.discountberry));
        latestProductsList.add(new LatestProducts(6,R.drawable.discountbrocoli));
    }

    private void populateOurProductList() {
        ourProductsList=new ArrayList<>();
        ourProductsList.add(new OurProducts("Watermelon","Watermelon has high water content and also contains fibre, food that supplies very few calories.","₹ 80","2","Kg",R.drawable.card4,R.drawable.b4));
        ourProductsList.add(new OurProducts("Papaya","Papaya is a tropical fruit mainly consumed for its orange, sweet and juicy pulp.","₹ 60","2","Kg",R.drawable.card3,R.drawable.b3));
        ourProductsList.add(new OurProducts("Strawberry","Strawberries are highly appreciated for their pleasant aroma and as an appetite stimulator.","₹ 85","12","Piece",R.drawable.card2,R.drawable.b1));
        ourProductsList.add(new OurProducts("Kiwi","Kiwis are small fruits that pack a lot of flavor and plenty of health benefits. Their green flesh is sweet and tangy.","₹ 100","1","Kg",R.drawable.card1,R.drawable.b2));
        ourProductsList.add(new OurProducts("Watermelon","Watermelon has high water content and also contains fibre, food that supplies very few calories","₹ 80","2","Kg",R.drawable.card4,R.drawable.b4));
    }

    private void setLatestProductAdapter(List<LatestProducts> dataList) {
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        latestProductRecycler.setLayoutManager(layoutManager);
        latestProductAdapter=new LatestProductAdapter(this,dataList);
        latestProductRecycler.setAdapter(latestProductAdapter);
    }

    private void setOurProductRecycler(List<OurProducts> dataList) {
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        ourProductRecycler.setLayoutManager(layoutManager);
        ourProductAdapter=new OurProductAdapter(this,dataList);
        ourProductRecycler.setAdapter(ourProductAdapter);
    }

    private void initViews() {
        latestProductRecycler=findViewById(R.id.dashboard_latest_product_recycler);
        ourProductRecycler=findViewById(R.id.dashboard_our_products_recycler);
        ic_cart=findViewById(R.id.dashboard_iv_cart);
        ic_profile=findViewById(R.id.dashboard_iv_profile);
        ic_filter=findViewById(R.id.dashboard_iv_filter);
        et_search=findViewById(R.id.dashboard_et_search);
        tv_vegetables=findViewById(R.id.dashboard_tv_vegetables);
        tv_fruits=findViewById(R.id.dashboard_tv_fruits);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.dashboard_iv_cart:
                Intent cartIntent=new Intent(this,CartActivity.class);
                startActivity(cartIntent);
                break;
            case R.id.dashboard_iv_profile:
                Intent profileIntent=new Intent(this,ProfileActivity.class);
                startActivity(profileIntent);
                break;
            case R.id.dashboard_iv_filter:
//                TODO filter categories
                break;
            case R.id.dashboard_tv_vegetables:
//                TODO Open activity containing vegetables
                break;
            case R.id.dashboard_tv_fruits:
//                TODO Open activity containing fruits
                break;

        }
    }
}