package com.ann9tation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ann9tation.e_commerce.R;
import com.ann9tation.model.Address;

import java.util.List;

public class AddressAdapter extends RecyclerView.Adapter<AddressAdapter.AddressViewHolder> {
    Context context;
    List<Address> addressList;

    public AddressAdapter(Context context, List<Address> addressList) {
        this.context = context;
        this.addressList = addressList;
    }

    @NonNull
    @Override
    public AddressViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.addeess_row_item,parent,false);
        return new AddressViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AddressViewHolder holder, int position) {
        holder.tv_uname.setText(addressList.get(position).getuName());
        holder.tv_address.setText(addressList.get(position).getuAddress());
        holder.tv_contact.setText(addressList.get(position).getuContact());
        holder.tv_tag.setText(addressList.get(position).getuAddressTAg());

    }

    @Override
    public int getItemCount() {
        return addressList.size();
    }

    public class AddressViewHolder extends RecyclerView.ViewHolder{

        TextView tv_uname,tv_address,tv_contact,tv_tag;

        public AddressViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_uname=itemView.findViewById(R.id.address_row_item_tv_user_name);
            tv_address=itemView.findViewById(R.id.address_row_item_tv_address);
            tv_contact=itemView.findViewById(R.id.address_row_item_tv_contact);
            tv_tag=itemView.findViewById(R.id.address_row_item_tv_tag);
        }
    }
}
