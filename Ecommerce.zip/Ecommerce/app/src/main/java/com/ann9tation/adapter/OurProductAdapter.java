package com.ann9tation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.ann9tation.e_commerce.Dashboard;
import com.ann9tation.e_commerce.ProductDetails;
import com.ann9tation.e_commerce.R;
import com.ann9tation.model.OurProducts;

import java.net.ConnectException;
import java.util.List;

public class OurProductAdapter extends RecyclerView.Adapter<OurProductAdapter.OurProductViewHolder> {

    Context context;
    List<OurProducts> ourProductsList;

    public OurProductAdapter(Context context, List<OurProducts> ourProductsList) {
        this.context = context;
        this.ourProductsList = ourProductsList;
    }

    @NonNull
    @Override
    public OurProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.our_product_row_item,parent,false);
        return new OurProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OurProductViewHolder holder, final int position) {
        holder.pNAme.setText(ourProductsList.get(position).getName());
        holder.pDescription.setText(ourProductsList.get(position).getDescription());
        holder.pPrice.setText(ourProductsList.get(position).getPrice());
        holder.pQty.setText(ourProductsList.get(position).getQuantity());
        holder.pUnit.setText(ourProductsList.get(position).getUnit());
        holder.bg.setBackgroundResource(ourProductsList.get(position).getImageUrl());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context,ProductDetails.class);
                i.putExtra("name",ourProductsList.get(position).getName());
                i.putExtra("image",ourProductsList.get(position).getBigimageUrl());
                i.putExtra("price",ourProductsList.get(position).getPrice());
                i.putExtra("weight/piece",ourProductsList.get(position).getQuantity()+" "+ourProductsList.get(position).getUnit());
                i.putExtra("desc",ourProductsList.get(position).getDescription());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return ourProductsList.size();
    }

    public class OurProductViewHolder extends RecyclerView.ViewHolder{

        TextView pNAme,pDescription,pPrice,pQty,pUnit;
        ConstraintLayout bg;
        public OurProductViewHolder(@NonNull View itemView) {
            super(itemView);
            pNAme=itemView.findViewById(R.id.our_product_row_item_tv_product_name);
            pPrice=itemView.findViewById(R.id.our_product_row_item_tv_price);
            pDescription=itemView.findViewById(R.id.our_product_row_item_tv_description);
            pQty=itemView.findViewById(R.id.our_product_row_item_tv_qty);
            pUnit=itemView.findViewById(R.id.our_product_row_item_tv_unit);
            bg=itemView.findViewById(R.id.our_product_row_item_cl_bg);
        }
    }
}
