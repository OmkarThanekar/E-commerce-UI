package com.ann9tation.model;

public class Address {
    String uName,uAddress,uContact,uAddressTAg;

    public Address(String uName, String uAddress, String uContact, String uAddressTAg) {
        this.uName = uName;
        this.uAddress = uAddress;
        this.uContact = uContact;
        this.uAddressTAg = uAddressTAg;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getuAddress() {
        return uAddress;
    }

    public void setuAddress(String uAddress) {
        this.uAddress = uAddress;
    }

    public String getuContact() {
        return uContact;
    }

    public void setuContact(String uContact) {
        this.uContact = uContact;
    }

    public String getuAddressTAg() {
        return uAddressTAg;
    }

    public void setuAddressTAg(String uAddressTAg) {
        this.uAddressTAg = uAddressTAg;
    }
}
