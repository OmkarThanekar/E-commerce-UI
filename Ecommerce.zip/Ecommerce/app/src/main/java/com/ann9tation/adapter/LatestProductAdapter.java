package com.ann9tation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ann9tation.e_commerce.R;
import com.ann9tation.model.LatestProducts;

import java.util.List;

public class LatestProductAdapter extends RecyclerView.Adapter<LatestProductAdapter.LatestProductViewHolder> {

    Context context;
    List<LatestProducts> latestProductsList;

    public LatestProductAdapter(Context context, List<LatestProducts> latestProductsList) {
        this.context = context;
        this.latestProductsList = latestProductsList;
    }

    @NonNull
    @Override
    public LatestProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.latest_product_row_item,parent,false);
        return new LatestProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LatestProductViewHolder holder, int position) {
        holder.latestPrductImage.setImageResource(latestProductsList.get(position).getImageurl());
    }

    @Override
    public int getItemCount() {
        return latestProductsList.size();
    }

    public static class LatestProductViewHolder extends RecyclerView.ViewHolder {
        ImageView latestPrductImage;
        public LatestProductViewHolder(@NonNull View itemView) {
            super(itemView);
            latestPrductImage=itemView.findViewById(R.id.latest_product_row_item_iv);
        }
    }
}
