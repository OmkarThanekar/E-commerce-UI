package com.ann9tation.e_commerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ann9tation.adapter.YourCartAdapter;
import com.ann9tation.model.YourCart;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView cartRecycler;
    private ImageView ic_back,ic_notification;
    private Button btn_proceed;
    private TextView tv_total;
    YourCartAdapter yourCartAdapter;
    private int total;
    List<YourCart> yourCartList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        initViews();
        initListner();

        populateYourCartList();

        setCartRecycler(yourCartList);




    }

    private void populateYourCartList() {
        yourCartList=new ArrayList<>();
        yourCartList.add(new YourCart("Watermelon","₹ 80","2","Kg",R.drawable.b4));
        yourCartList.add(new YourCart("Papaya","₹ 60","2","Kg",R.drawable.b3));
        yourCartList.add(new YourCart("kiwi","₹ 100","1","Kg",R.drawable.b2));
        yourCartList.add(new YourCart("Strawberry","₹ 85","1","Dozen",R.drawable.b1));
    }

    private void setCartRecycler(List<YourCart> datalist) {
        cartRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        yourCartAdapter=new YourCartAdapter(this,datalist);
        cartRecycler.setAdapter(yourCartAdapter);
        yourCartAdapter.setOnClickListener(new YourCartAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            //TODO Onitemclick
                Toast.makeText(CartActivity.this, "Item : "+position, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPlusClick(int position, TextView tv_Quantity, TextView tv_Subtotal, String price) {
                tv_Quantity.setText(Integer.toString(Integer.parseInt(tv_Quantity.getText().toString())+1));
                tv_Subtotal.setText(Integer.toString(Integer.parseInt(tv_Quantity.getText().toString())*Integer.parseInt(price.substring(2))));
                total=total+Integer.parseInt(tv_Subtotal.getText().toString());
            }

            @Override
            public void onMinusClick(int position, TextView tv_Quantity,TextView tv_Subtotal, String price) {
                if (Integer.parseInt(tv_Quantity.getText().toString())>1) {
                    tv_Quantity.setText(Integer.toString(Integer.parseInt(tv_Quantity.getText().toString()) - 1));
                    tv_Subtotal.setText(Integer.toString(Integer.parseInt(tv_Quantity.getText().toString()) * Integer.parseInt(price.substring(2))));
                }
                else
                    Toast.makeText(CartActivity.this, "Minimum Quantity should be 1.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onDeleteClick(int position) {
//                TODO remove from cart
                Toast.makeText(CartActivity.this, "Item at "+position+" sucessfully removed from cart.", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void initListner() {
        ic_notification.setOnClickListener(this);
        ic_back.setOnClickListener(this);
        btn_proceed.setOnClickListener(this);
    }

    private void initViews() {
        cartRecycler=findViewById(R.id.cart_recycler);
        btn_proceed=findViewById(R.id.cart_btn_proceed);
        ic_back=findViewById(R.id.cart_iv_back);
        ic_notification=findViewById(R.id.cart_iv_notification);
        tv_total=findViewById(R.id.cart_tv_total);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.cart_iv_back:
                onBackPressed();
                break;
            case R.id.cart_iv_notification:
//                TODO notification activity
                break;
            case R.id.cart_btn_proceed:
                Toast.makeText(this, "Proceed to checkout...", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}